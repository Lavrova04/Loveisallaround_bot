# 🌟 SoulMatch Bot

Добро пожаловать в **SoulMatch** — бот для знакомств всех полов и всех городов мира!  
Здесь ты можешь находить людей по интересам, лайкать анкеты и получать **мэтчи** 💘  

---

## 🚀 Как запустить SoulMatch на iPhone через Render

### 1️⃣ Создай бота в Telegram
- Перейди в [@BotFather](https://t.me/BotFather)  
- Введи команду `/newbot` → задай имя и @username  
- Скопируй `BOT_TOKEN`

### 2️⃣ Залей проект в GitHub
1. Скачай ZIP проекта 📦  
2. Создай репозиторий на [GitHub](https://github.com)  
3. Загрузите файлы (можно прямо ZIP)  

### 3️⃣ Подключи Render
1. Перейди на [render.com](https://render.com)  
2. Зарегистрируйся (можно через GitHub)  
3. Нажми **New → Web Service**  
4. Выбери свой репозиторий `soulmatch-bot`  

### 4️⃣ Настрой сервис
- **Build Command**:
```bash
pip install -r requirements.txt
```
- **Start Command**:
```bash
python -m app.main
```

### 5️⃣ Добавь переменные окружения
В разделе **Environment → Add Environment Variable**:  
- `BOT_TOKEN` = твой токен из @BotFather  
- `PROVIDER_TOKEN` = токен для оплаты (можно добавить позже)  

### 6️⃣ Запусти 🚀
Нажми **Deploy** → дождись запуска → открой своего бота в Telegram и жми **Start** ✨  

---

## 💎 Возможности SoulMatch
- Создание анкеты 📸  
- Лайки и скипы 💖  
- Уведомления о **мэтчах** 🔔  
- Ограничение свайпов в день 🕒  
- Premium подписка с оплатой 💳  

---

Удачи! 🎉 SoulMatch ждёт своих первых пользователей ❤️
